from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import *
from .forms import VoteForm, CreateUserForm
from django.forms import inlineformset_factory
from .filters import VoteFilter
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login as lg, logout
from django.contrib.auth.decorators import login_required

# Create your views here.


def register(request): 
	if request.user.is_authenticated:
		return redirect('home')
	else:
		form = CreateUserForm()
		if request.method == 'POST':
			#print('Printing Post', request.POST)
			form = CreateUserForm(request.POST)
			if form.is_valid():
				form.save()
				user = form.cleaned_data.get('username')
				messages.success(request, 'Account was created for' + user)
				return redirect('/')
		context = {'form':form}
		return render(request, 'accounts/register.html', context)


def login(request):
	if request.method == 'POST':
		username = request.POST.get('username')
		password =request.POST.get('password')

		user = authenticate(request, username=username, password=password)

		if user is not None:
			lg(request, user)
			return redirect('home')
		else:
			messages.info(request, 'Username OR password is incorrect')

		context = {}
	return render(request, 'accounts/login.html')

def logoutUser(request):
	logout(request)
	return redirect('login')


@login_required(login_url='login')
def home(request):
	vote = Vote.objects.all()
	voters = Voter.objects.all()
	candidates = Candidate.objects.all()

	total_votes = vote.count()
	total_voters = voters.count()
	total_candidates = candidates.count()
	
	context = {'vote': vote, 'voters':voters, 'candidates':candidates,'total_voters':total_voters,'total_candidates':total_candidates,'total_votes':total_votes}
	return render(request, 'accounts/dashboard.html', context)

@login_required(login_url='login')
def voterPage(request, pk):
	candidates = Candidate.objects.all()
	voter = Voter.objects.get(id=pk)
	vote = voter.vote_set.all()
	total_votes = vote.count()

	myFilter = VoteFilter(request.GET, queryset=vote)
	vote = myFilter.qs
	total_candidates = candidates.count()
	context = {'voter':voter, 'vote': vote,'total_candidates':total_candidates,'total_votes':total_votes,'myFilter':myFilter}
	return render(request, 'accounts/voter_page.html',context)

@login_required(login_url='login')
def vote(request, pk):
	OrderFormSet = inlineformset_factory( Voter, Vote, fields=('candidate','status'))
	voter = Voter.objects.get(id=pk)
	formset = OrderFormSet(queryset=Vote.objects.none(),instance=voter)

	#form = VoteForm(initial={'voter':voter})

	if request.method == 'POST':
		#print('Printing Post', request.POST)
		formset = VoteForm(request.POST,instance=voter)
		if formset.is_valid():
			formset.save()
			return redirect('/')
	context = {'formset':formset}
	return render(request, 'accounts/balott_form.html', context)

@login_required(login_url='login')
def update(request, pk):
	vote = Vote.objects.get(id=pk)
	form = VoteForm(instance=vote)

	if request.method == 'POST':
		#print('Printing Post', request.POST)
		form = VoteForm(request.POST, instance=vote)
		if form.is_valid():
			form.save()
			return redirect('/')
	context = {'form':form}
	return render(request, 'accounts/balott_form.html', context)

@login_required(login_url='login')
def delete(request, pk):
	vote = Vote.objects.get(id=pk)

	if request.method == "POST":
		vote.delete()

	context = {'item':vote}
	return render(request, 'accounts/balott_form.html', context)
