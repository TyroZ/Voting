from django.db import models

# Create your models here.

class Voter(models.Model):
	name = models.CharField(max_length=200, null=True)
	surname = models.CharField(max_length=200, null=True)
	email = models.CharField(max_length=200, null=True)
	idNum = models.CharField(max_length=200, null=True)
	date_created = models.DateTimeField(auto_now_add=True,null=True)
	dOB = models.DateTimeField(auto_now_add=True,null=True)

	def __str__(self):
		return self.name

class Candidate(models.Model):
	name = models.CharField(max_length=200, null=True)
	party = models.CharField(max_length=200, null=True)
	surname = models.CharField(max_length=200, null=True)
	role = models.CharField(max_length=200, null=True)
	district = models.CharField(max_length=200, null=True)
	date_created = models.DateTimeField(auto_now_add=True,null=True)

	def __str__(self):
		return self.name

class Vote(models.Model):
	STATUS = (
		('Pending', 'Pending'),
		('Not Voted','Not Voted')
		)

	voter = models.ForeignKey(Voter, null=True, on_delete=models.SET_NULL)
	candidate = models.ForeignKey(Candidate, null=True, on_delete=models.SET_NULL)
	date_created = models.DateTimeField(auto_now_add=True,null=True)
	status = models.CharField(max_length=200, null=True,choices=STATUS)
	note = models.CharField(max_length=1000, null=True)


	def __str__(self):
		return self.candidate.name