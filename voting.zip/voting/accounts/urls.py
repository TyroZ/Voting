from django.shortcuts import render
from django.http import HttpResponse
from django.urls import path
from . import views


urlpatterns = [
    path('', views.home, name="home"),
    path('register/', views.register, name="register"),
    path('login/', views.login, name="login"),    
    path('logout/', views.logoutUser, name="logout"),
    path('voter/<str:pk>/', views.voterPage, name="voter"),
    path('vote/<str:pk>/', views.vote, name="vote"),
    path('update/<str:pk>/', views.update, name="update"),
    path('delete/<str:pk>/', views.delete, name="delete"),


]